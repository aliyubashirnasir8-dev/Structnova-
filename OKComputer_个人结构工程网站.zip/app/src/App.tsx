import { useEffect, useRef, useState } from 'react'
import './App.css'
import { 
  Menu, 
  X, 
  ArrowRight, 
  Building2, 
  ClipboardCheck, 
  Users, 
  HardHat, 
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  Instagram,
  Linkedin,
  Twitter,
  ArrowUpRight,
  Calendar
} from 'lucide-react'

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [scrollY, setScrollY] = useState(0)
  const [isVisible, setIsVisible] = useState<Record<string, boolean>>({})
  
  const heroRef = useRef<HTMLDivElement>(null)
  const aboutRef = useRef<HTMLDivElement>(null)
  const servicesRef = useRef<HTMLDivElement>(null)
  const projectsRef = useRef<HTMLDivElement>(null)
  const testimonialsRef = useRef<HTMLDivElement>(null)
  const blogRef = useRef<HTMLDivElement>(null)
  const footerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }
    
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible((prev) => ({ ...prev, [entry.target.id]: true }))
          }
        })
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    )

    const sections = ['hero', 'about', 'services', 'projects', 'testimonials', 'blog', 'footer']
    sections.forEach((id) => {
      const element = document.getElementById(id)
      if (element) observer.observe(element)
    })

    return () => observer.disconnect()
  }, [])

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
      setIsMenuOpen(false)
    }
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrollY > 100 ? 'bg-white/90 backdrop-blur-md shadow-sm' : 'bg-transparent'
      }`}>
        <div className="w-full px-6 lg:px-12">
          <div className="flex items-center justify-between h-20">
            <a href="#" className="font-display text-2xl tracking-tight">
              Structura
            </a>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              {['About', 'Services', 'Projects', 'Testimonials', 'Blog'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="text-sm font-medium text-gray-text hover:text-black transition-colors link-underline"
                >
                  {item}
                </button>
              ))}
              <button 
                onClick={() => scrollToSection('footer')}
                className="btn-primary text-sm py-3 px-6"
              >
                Contact Us
              </button>
            </div>
            
            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="px-6 py-4 space-y-4">
              {['About', 'Services', 'Projects', 'Testimonials', 'Blog'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="block w-full text-left text-lg font-medium py-2"
                >
                  {item}
                </button>
              ))}
              <button 
                onClick={() => scrollToSection('footer')}
                className="btn-primary w-full text-center"
              >
                Contact Us
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section 
        id="hero" 
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center overflow-hidden blueprint-grid grain-overlay"
      >
        {/* Floating Images */}
        <div 
          className={`absolute top-24 right-8 lg:right-24 w-32 h-32 lg:w-48 lg:h-48 rounded-2xl overflow-hidden shadow-structural animate-float transition-all duration-1000 ${
            isVisible['hero'] ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
          }`}
          style={{ transitionDelay: '0.4s' }}
        >
          <img 
            src="/hero-1.jpg" 
            alt="Construction worker" 
            className="w-full h-full object-cover"
          />
        </div>
        
        <div 
          className={`absolute bottom-32 left-8 lg:left-24 w-36 h-36 lg:w-52 lg:h-52 rounded-2xl overflow-hidden shadow-structural animate-float-delayed transition-all duration-1000 ${
            isVisible['hero'] ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
          }`}
          style={{ transitionDelay: '0.6s' }}
        >
          <img 
            src="/hero-2.jpg" 
            alt="Construction workers" 
            className="w-full h-full object-cover"
          />
        </div>
        
        <div 
          className={`absolute bottom-16 right-16 lg:right-48 w-28 h-28 lg:w-40 lg:h-40 rounded-2xl overflow-hidden shadow-structural animate-float-delayed-2 transition-all duration-1000 ${
            isVisible['hero'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
          }`}
          style={{ transitionDelay: '0.8s' }}
        >
          <img 
            src="/hero-3.jpg" 
            alt="Construction site" 
            className="w-full h-full object-cover"
          />
        </div>
        
        {/* Hero Content */}
        <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
          <h1 
            className={`font-display text-6xl sm:text-7xl md:text-8xl lg:text-9xl leading-none tracking-tight mb-8 transition-all duration-1000 ${
              isVisible['hero'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
            }`}
          >
            STRUCTURAL
            <br />
            <span className="text-orange">DESIGN</span>
          </h1>
          
          <p 
            className={`text-lg md:text-xl text-gray-text max-w-2xl mx-auto mb-12 transition-all duration-1000 ${
              isVisible['hero'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '0.3s' }}
          >
            We craft the bones of buildings. Engineering the future with precision 
            and artistic vision.
          </p>
          
          <div 
            className={`flex flex-col sm:flex-row gap-4 justify-center transition-all duration-1000 ${
              isVisible['hero'] ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
            }`}
            style={{ transitionDelay: '0.5s' }}
          >
            <button 
              onClick={() => scrollToSection('projects')}
              className="btn-primary flex items-center justify-center gap-2"
            >
              Explore Our Work
              <ArrowRight size={18} />
            </button>
            <button 
              onClick={() => scrollToSection('about')}
              className="btn-outline"
            >
              Learn More
            </button>
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-gray-text">
          <span className="text-xs uppercase tracking-widest">Scroll</span>
          <div className="w-px h-12 bg-gray-text/30 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1/2 bg-orange animate-pulse" />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section 
        id="about" 
        ref={aboutRef}
        className="py-24 lg:py-32 px-6 lg:px-12"
      >
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Image */}
            <div 
              className={`relative transition-all duration-1000 ${
                isVisible['about'] ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
              }`}
            >
              <div className="relative rounded-3xl overflow-hidden aspect-[4/3]">
                <img 
                  src="/about.jpg" 
                  alt="About Structura" 
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Experience Badge */}
              <div className="absolute -bottom-6 -right-6 bg-orange text-white rounded-2xl p-6 shadow-structural">
                <div className="font-display text-4xl">20+</div>
                <div className="text-sm opacity-80">Years Experience</div>
              </div>
            </div>
            
            {/* Content */}
            <div 
              className={`transition-all duration-1000 ${
                isVisible['about'] ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
              }`}
              style={{ transitionDelay: '0.2s' }}
            >
              <span className="text-orange text-sm font-medium uppercase tracking-widest mb-4 block">
                About Us
              </span>
              <h2 className="font-display text-4xl md:text-5xl lg:text-6xl mb-6">
                Building the Future with Precision
              </h2>
              <p className="text-gray-text text-lg mb-6">
                We are a team of visionary engineers and architects dedicated to reshaping 
                skylines. With over 20 years of experience, we bring concepts to life with 
                structural integrity and innovative design.
              </p>
              <p className="text-gray-text mb-8">
                Our approach combines cutting-edge technology with time-tested engineering 
                principles, ensuring every project we undertake stands the test of time.
              </p>
              
              {/* Stats */}
              <div className="grid grid-cols-2 gap-8">
                <div>
                  <div className="font-display text-4xl text-orange">150+</div>
                  <div className="text-gray-text">Projects Completed</div>
                </div>
                <div>
                  <div className="font-display text-4xl text-orange">25</div>
                  <div className="text-gray-text">Awards Won</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section 
        id="services" 
        ref={servicesRef}
        className="py-24 lg:py-32 px-6 lg:px-12 bg-gray-light"
      >
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span 
              className={`text-orange text-sm font-medium uppercase tracking-widest mb-4 block transition-all duration-700 ${
                isVisible['services'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
            >
              Our Services
            </span>
            <h2 
              className={`font-display text-4xl md:text-5xl lg:text-6xl transition-all duration-700 ${
                isVisible['services'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
              style={{ transitionDelay: '0.1s' }}
            >
              What We Do
            </h2>
          </div>
          
          {/* Service Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                num: '01',
                title: 'Structural Analysis',
                desc: 'Comprehensive analysis of structural integrity using advanced simulation tools.',
                icon: Building2
              },
              {
                num: '02',
                title: 'Blueprint Design',
                desc: 'Detailed architectural blueprints and technical drawings for construction.',
                icon: ClipboardCheck
              },
              {
                num: '03',
                title: 'Project Management',
                desc: 'End-to-end project oversight ensuring timely and budget-compliant delivery.',
                icon: Users
              },
              {
                num: '04',
                title: 'Site Inspection',
                desc: 'Thorough on-site evaluations to ensure safety and quality standards.',
                icon: HardHat
              },
              {
                num: '05',
                title: 'Consulting',
                desc: 'Expert advice on structural engineering challenges and solutions.',
                icon: MessageSquare
              }
            ].map((service, index) => (
              <div
                key={service.num}
                className={`group bg-white rounded-2xl p-8 hover:shadow-structural transition-all duration-500 cursor-pointer ${
                  isVisible['services'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: `${0.2 + index * 0.1}s` }}
              >
                <div className="flex items-start justify-between mb-6">
                  <span className="font-display text-3xl text-orange">{service.num}</span>
                  <service.icon className="w-6 h-6 text-gray-text group-hover:text-orange transition-colors" />
                </div>
                <h3 className="font-display text-2xl mb-3 group-hover:text-orange transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-text text-sm leading-relaxed">
                  {service.desc}
                </p>
                <div className="mt-6 flex items-center gap-2 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                  <span>Learn More</span>
                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section 
        id="projects" 
        ref={projectsRef}
        className="py-24 lg:py-32 px-6 lg:px-12"
      >
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-16">
            <div>
              <span 
                className={`text-orange text-sm font-medium uppercase tracking-widest mb-4 block transition-all duration-700 ${
                  isVisible['projects'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                }`}
              >
                Our Projects
              </span>
              <h2 
                className={`font-display text-4xl md:text-5xl lg:text-6xl transition-all duration-700 ${
                  isVisible['projects'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                }`}
                style={{ transitionDelay: '0.1s' }}
              >
                Featured Work
              </h2>
            </div>
            <button 
              className={`btn-outline mt-6 md:mt-0 transition-all duration-700 ${
                isVisible['projects'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
              style={{ transitionDelay: '0.2s' }}
            >
              View All Projects
            </button>
          </div>
          
          {/* Projects Grid */}
          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                title: 'Skyline Tower',
                category: 'Commercial',
                image: '/project-1.jpg'
              },
              {
                title: 'Harbor Bridge',
                category: 'Infrastructure',
                image: '/project-2.jpg'
              },
              {
                title: 'Metro Station',
                category: 'Public',
                image: '/project-3.jpg'
              },
              {
                title: 'Green Complex',
                category: 'Residential',
                image: '/project-4.jpg'
              }
            ].map((project, index) => (
              <div
                key={project.title}
                className={`group relative rounded-3xl overflow-hidden image-hover-zoom cursor-pointer ${
                  isVisible['projects'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
                }`}
                style={{ transitionDelay: `${0.3 + index * 0.15}s` }}
              >
                <div className="aspect-[4/3]">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />
                {/* Content */}
                <div className="absolute bottom-0 left-0 right-0 p-8">
                  <span className="text-white/70 text-sm uppercase tracking-widest mb-2 block">
                    {project.category}
                  </span>
                  <h3 className="font-display text-3xl text-white group-hover:text-orange transition-colors">
                    {project.title}
                  </h3>
                  <div className="mt-4 flex items-center gap-2 text-white opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="text-sm">View Project</span>
                    <ArrowUpRight size={16} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section 
        id="testimonials" 
        ref={testimonialsRef}
        className="py-24 lg:py-32 px-6 lg:px-12 bg-black text-white"
      >
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span 
              className={`text-orange text-sm font-medium uppercase tracking-widest mb-4 block transition-all duration-700 ${
                isVisible['testimonials'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
            >
              Testimonials
            </span>
            <h2 
              className={`font-display text-4xl md:text-5xl lg:text-6xl transition-all duration-700 ${
                isVisible['testimonials'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
              style={{ transitionDelay: '0.1s' }}
            >
              What Clients Say
            </h2>
          </div>
          
          <TestimonialCarousel isVisible={isVisible['testimonials']} />
        </div>
      </section>

      {/* Blog Section */}
      <section 
        id="blog" 
        ref={blogRef}
        className="py-24 lg:py-32 px-6 lg:px-12"
      >
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-16">
            <div>
              <span 
                className={`text-orange text-sm font-medium uppercase tracking-widest mb-4 block transition-all duration-700 ${
                  isVisible['blog'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                }`}
              >
                Our Blog
              </span>
              <h2 
                className={`font-display text-4xl md:text-5xl lg:text-6xl transition-all duration-700 ${
                  isVisible['blog'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                }`}
                style={{ transitionDelay: '0.1s' }}
              >
                Latest Insights
              </h2>
            </div>
            <button 
              className={`btn-outline mt-6 md:mt-0 transition-all duration-700 ${
                isVisible['blog'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
              style={{ transitionDelay: '0.2s' }}
            >
              View All Articles
            </button>
          </div>
          
          {/* Blog Posts */}
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: 'The Future of Sustainable Concrete',
                date: 'Jan 15, 2026',
                image: '/hero-1.jpg',
                excerpt: 'Exploring innovative materials that reduce environmental impact.'
              },
              {
                title: 'Earthquake Resistant Design Principles',
                date: 'Jan 10, 2026',
                image: '/hero-2.jpg',
                excerpt: 'Key strategies for building structures that withstand seismic activity.'
              },
              {
                title: 'Top 10 Skyscrapers of 2025',
                date: 'Jan 05, 2026',
                image: '/hero-3.jpg',
                excerpt: 'A look at the most impressive architectural achievements of the year.'
              }
            ].map((post, index) => (
              <article
                key={post.title}
                className={`group cursor-pointer transition-all duration-700 ${
                  isVisible['blog'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
                }`}
                style={{ transitionDelay: `${0.3 + index * 0.1}s` }}
              >
                <div className="rounded-2xl overflow-hidden mb-6 image-hover-zoom">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full aspect-[4/3] object-cover"
                  />
                </div>
                <div className="flex items-center gap-2 text-gray-text text-sm mb-3">
                  <Calendar size={14} />
                  <span>{post.date}</span>
                </div>
                <h3 className="font-display text-xl group-hover:text-orange transition-colors mb-2">
                  {post.title}
                </h3>
                <p className="text-gray-text text-sm">
                  {post.excerpt}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer 
        id="footer" 
        ref={footerRef}
        className="py-24 lg:py-32 px-6 lg:px-12 bg-black text-white"
      >
        <div className="max-w-7xl mx-auto">
          {/* CTA */}
          <div 
            className={`text-center mb-24 transition-all duration-1000 ${
              isVisible['footer'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
            }`}
          >
            <h2 className="font-display text-5xl md:text-7xl lg:text-8xl mb-8">
              LET'S <span className="text-orange">BUILD</span>
              <br />
              TOGETHER
            </h2>
            <button className="btn-primary text-lg py-4 px-10">
              Start a Project
            </button>
          </div>
          
          {/* Footer Grid */}
          <div 
            className={`grid md:grid-cols-4 gap-12 pt-12 border-t border-white/10 transition-all duration-1000 ${
              isVisible['footer'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '0.2s' }}
          >
            {/* Brand */}
            <div>
              <div className="font-display text-2xl mb-4">Structura</div>
              <p className="text-white/60 text-sm leading-relaxed">
                Engineering the future with precision and creativity. Building structures that stand the test of time.
              </p>
            </div>
            
            {/* Links */}
            <div>
              <h4 className="font-medium mb-4">Quick Links</h4>
              <ul className="space-y-2">
                {['About', 'Services', 'Projects', 'Blog'].map((link) => (
                  <li key={link}>
                    <button
                      onClick={() => scrollToSection(link.toLowerCase())}
                      className="text-white/60 hover:text-white transition-colors text-sm"
                    >
                      {link}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            
            {/* Contact */}
            <div>
              <h4 className="font-medium mb-4">Contact</h4>
              <ul className="space-y-2 text-white/60 text-sm">
                <li>hello@structura.com</li>
                <li>+1 (555) 123-4567</li>
                <li>123 Design Street<br />New York, NY 10001</li>
              </ul>
            </div>
            
            {/* Social */}
            <div>
              <h4 className="font-medium mb-4">Follow Us</h4>
              <div className="flex gap-4">
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-orange transition-colors">
                  <Instagram size={18} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-orange transition-colors">
                  <Linkedin size={18} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-orange transition-colors">
                  <Twitter size={18} />
                </a>
              </div>
            </div>
          </div>
          
          {/* Copyright */}
          <div 
            className={`mt-12 pt-8 border-t border-white/10 text-center text-white/40 text-sm transition-all duration-1000 ${
              isVisible['footer'] ? 'opacity-100' : 'opacity-0'
            }`}
            style={{ transitionDelay: '0.4s' }}
          >
            © 2026 Structura Design. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}

// Testimonial Carousel Component
function TestimonialCarousel({ isVisible }: { isVisible: boolean }) {
  const [current, setCurrent] = useState(0)
  
  const testimonials = [
    {
      quote: "Structura transformed our vision into a concrete reality. Their attention to detail and engineering excellence is unmatched.",
      author: "Sarah Johnson",
      role: "CEO, Skyline Developments",
      image: "/reviewer-1.jpg"
    },
    {
      quote: "Precision and professionalism at every step. They delivered our project on time and exceeded all expectations.",
      author: "Michael Chen",
      role: "Director, Urban Infrastructure",
      image: "/reviewer-2.jpg"
    },
    {
      quote: "The best structural team we've ever worked with. Their innovative solutions saved us time and money.",
      author: "Emily Davis",
      role: "Project Manager, BuildCorp",
      image: "/reviewer-3.jpg"
    }
  ]
  
  const next = () => setCurrent((prev) => (prev + 1) % testimonials.length)
  const prev = () => setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  
  return (
    <div className={`relative max-w-4xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`} style={{ transitionDelay: '0.2s' }}>
      {/* Testimonial Card */}
      <div className="relative bg-white/5 rounded-3xl p-8 md:p-12 backdrop-blur-sm">
        <div className="flex flex-col md:flex-row items-center gap-8">
          {/* Author Image */}
          <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden flex-shrink-0 border-2 border-orange">
            <img 
              src={testimonials[current].image} 
              alt={testimonials[current].author}
              className="w-full h-full object-cover"
            />
          </div>
          
          {/* Content */}
          <div className="text-center md:text-left">
            <p className="text-lg md:text-xl leading-relaxed mb-6 text-white/90">
              "{testimonials[current].quote}"
            </p>
            <div>
              <div className="font-display text-xl text-orange">{testimonials[current].author}</div>
              <div className="text-white/60 text-sm">{testimonials[current].role}</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <div className="flex items-center justify-center gap-4 mt-8">
        <button 
          onClick={prev}
          className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-orange transition-colors"
        >
          <ChevronLeft size={20} />
        </button>
        
        {/* Dots */}
        <div className="flex gap-2">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrent(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                index === current ? 'w-8 bg-orange' : 'bg-white/30 hover:bg-white/50'
              }`}
            />
          ))}
        </div>
        
        <button 
          onClick={next}
          className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-orange transition-colors"
        >
          <ChevronRight size={20} />
        </button>
      </div>
    </div>
  )
}

export default App
